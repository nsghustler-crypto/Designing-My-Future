import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Cpu, 
  Eye, 
  Battery, 
  Wifi, 
  Code, 
  Play, 
  BookOpen, 
  Layers, 
  Zap,
  ChevronRight,
  Star,
  Check,
  Menu,
  X,
  ArrowRight,
  Settings,
  Move,
  Lightbulb,
  Users,
  Trophy
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

gsap.registerPlugin(ScrollTrigger);

// Navigation Component
function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'Features', href: '#features' },
    { name: 'How It Works', href: '#how-it-works' },
    { name: 'Designer', href: '#designer' },
    { name: 'Learn', href: '#learn' },
    { name: 'Pricing', href: '#pricing' },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/90 backdrop-blur-md shadow-sm' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#F7C600] rounded-lg flex items-center justify-center">
              <Cpu className="w-6 h-6 text-black" />
            </div>
            <span className="font-bold text-xl text-black font-['Montserrat']">BotForge</span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-gray-700 hover:text-[#F7C600] transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <Button 
              className="bg-[#F7C600] hover:bg-[#e0b500] text-black font-semibold px-6"
            >
              Start Building
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t py-4">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-sm font-medium text-gray-700 hover:text-[#F7C600] transition-colors px-4 py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <div className="px-4 pt-2">
                <Button className="w-full bg-[#F7C600] hover:bg-[#e0b500] text-black font-semibold">
                  Start Building
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

// Hero Section
function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const robotRef = useRef<HTMLImageElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Text animation
      gsap.fromTo(
        textRef.current?.querySelectorAll('.animate-item') || [],
        { y: 100, opacity: 0 },
        { 
          y: 0, 
          opacity: 1, 
          duration: 0.8, 
          stagger: 0.1,
          ease: 'power3.out',
          delay: 0.2
        }
      );

      // Robot animation
      gsap.fromTo(
        robotRef.current,
        { scale: 0.8, opacity: 0, rotateY: -30 },
        { 
          scale: 1, 
          opacity: 1, 
          rotateY: -15,
          duration: 1.2, 
          ease: 'power3.out',
          delay: 0.4
        }
      );

      // Parallax on scroll
      gsap.to(robotRef.current, {
        y: -100,
        rotateY: 0,
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      id="hero" 
      ref={heroRef}
      className="relative min-h-screen bg-black overflow-hidden flex items-center"
    >
      {/* Circuit Background */}
      <div className="absolute inset-0 bg-circuit opacity-50" />
      
      {/* Animated Grid Lines */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute h-px bg-gradient-to-r from-transparent via-[#F7C600]/30 to-transparent"
            style={{
              top: `${20 + i * 15}%`,
              left: 0,
              right: 0,
              animation: `pulse 3s ease-in-out ${i * 0.5}s infinite`,
            }}
          />
        ))}
      </div>

      {/* Floating Decorative Shapes */}
      <div className="absolute top-20 right-20 w-32 h-32 border-2 border-[#F7C600]/20 rounded-full animate-spin-slow" />
      <div className="absolute bottom-40 left-10 w-20 h-20 border border-[#F7C600]/30 rotate-45 animate-bounce-subtle" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div ref={textRef} className="text-left z-10">
            <div className="animate-item inline-flex items-center gap-2 bg-[#F7C600]/10 border border-[#F7C600]/30 rounded-full px-4 py-2 mb-6">
              <Zap className="w-4 h-4 text-[#F7C600]" />
              <span className="text-sm text-[#F7C600] font-medium">Learn Robotics Through Play</span>
            </div>
            
            <h1 className="animate-item text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 font-['Montserrat'] leading-tight">
              BUILD YOUR<br />
              <span className="text-[#F7C600]">OWN ROBOT</span>
            </h1>
            
            <p className="animate-item text-lg text-gray-400 mb-8 max-w-lg">
              BotForge is the all-in-one platform where beginners and enthusiasts 
              design, simulate, and program their dream robots. No experience needed!
            </p>
            
            <div className="animate-item flex flex-wrap gap-4">
              <Button 
                size="lg"
                className="bg-[#F7C600] hover:bg-[#e0b500] text-black font-bold px-8 py-6 text-lg group"
              >
                Start Building Free
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg"
              >
                <Play className="mr-2 w-5 h-5" />
                Watch Demo
              </Button>
            </div>

            <div className="animate-item flex items-center gap-8 mt-12">
              <div>
                <div className="text-3xl font-bold text-[#F7C600]">50K+</div>
                <div className="text-sm text-gray-500">Robots Built</div>
              </div>
              <div className="w-px h-12 bg-gray-700" />
              <div>
                <div className="text-3xl font-bold text-[#F7C600]">100+</div>
                <div className="text-sm text-gray-500">Lessons</div>
              </div>
              <div className="w-px h-12 bg-gray-700" />
              <div>
                <div className="text-3xl font-bold text-[#F7C600]">4.9</div>
                <div className="text-sm text-gray-500">User Rating</div>
              </div>
            </div>
          </div>

          {/* Robot Image */}
          <div className="relative flex justify-center lg:justify-end">
            <img
              ref={robotRef}
              src="/hero-robot.png"
              alt="Friendly Robot"
              className="w-full max-w-lg animate-float drop-shadow-2xl"
              style={{ perspective: '1000px' }}
            />
            
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-[#F7C600]/10 blur-3xl rounded-full -z-10" />
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}

// Features Section
function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        cardsRef.current?.querySelectorAll('.feature-card') || [],
        { y: 60, opacity: 0, rotateX: 20 },
        {
          y: 0,
          opacity: 1,
          rotateX: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const features = [
    {
      icon: <Settings className="w-8 h-8" />,
      title: 'Visual Robot Designer',
      description: 'Drag, drop, and customize robot parts. Build anything from simple cars to complex humanoids.',
      image: '/feature-designer.jpg',
    },
    {
      icon: <Play className="w-8 h-8" />,
      title: 'Virtual Simulator',
      description: 'Test your robot in a realistic physics engine. See how it moves, senses, and responds.',
      image: '/feature-simulator.jpg',
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: 'Step-by-Step Lessons',
      description: 'From zero to hero. Learn robotics concepts with interactive tutorials and quizzes.',
      image: '/feature-learning.jpg',
    },
    {
      icon: <Layers className="w-8 h-8" />,
      title: 'Project Library',
      description: 'Access 50+ starter templates. From line followers to obstacle avoiders.',
      image: '/feature-library.jpg',
    },
  ];

  return (
    <section 
      id="features" 
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            Features
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4 font-['Montserrat']">
            Everything You Need to Build
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            BotForge provides all the tools you need to design, simulate, and learn robotics 
            in one powerful platform.
          </p>
        </div>

        <div ref={cardsRef} className="grid md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="feature-card group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              style={{ perspective: '1000px' }}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 w-14 h-14 bg-[#F7C600] rounded-xl flex items-center justify-center text-black">
                  {feature.icon}
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-black mb-2 font-['Montserrat']">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

// How It Works Section
function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const stepsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate steps on scroll
      gsap.fromTo(
        stepsRef.current?.querySelectorAll('.step-item') || [],
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate connector line
      gsap.fromTo(
        '.connector-line',
        { scaleY: 0 },
        {
          scaleY: 1,
          duration: 1.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 50%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const steps = [
    {
      number: '01',
      title: 'Design',
      description: 'Choose from hundreds of parts - motors, sensors, wheels, and controllers. Drag and drop to build your robot.',
      image: '/step-design.jpg',
    },
    {
      number: '02',
      title: 'Simulate',
      description: 'Test your robot in our virtual physics environment. See how it moves, detects obstacles, and responds to commands.',
      image: '/step-simulate.jpg',
    },
    {
      number: '03',
      title: 'Program',
      description: 'Use our visual block-based coding system to program robot behavior. No typing required - just drag logic blocks!',
      image: '/step-program.jpg',
    },
    {
      number: '04',
      title: 'Export',
      description: 'Get a complete parts list and building instructions. Build your robot in real life with confidence!',
      image: '/step-export.jpg',
    },
  ];

  return (
    <section 
      id="how-it-works" 
      ref={sectionRef}
      className="py-24 bg-[#F7F7F7]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            How It Works
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4 font-['Montserrat']">
            From Idea to Robot in 4 Steps
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our guided process makes robotics accessible to everyone, regardless of experience level.
          </p>
        </div>

        <div ref={stepsRef} className="relative">
          {/* Connector Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-1 bg-gray-200 -translate-x-1/2 hidden md:block">
            <div className="connector-line absolute inset-0 bg-[#F7C600] origin-top" />
          </div>

          <div className="space-y-16">
            {steps.map((step, index) => (
              <div 
                key={index}
                className={`step-item flex flex-col md:flex-row items-center gap-8 ${
                  index % 2 === 1 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Image */}
                <div className="flex-1 w-full">
                  <div className="relative rounded-2xl overflow-hidden shadow-xl group">
                    <img
                      src={step.image}
                      alt={step.title}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  </div>
                </div>

                {/* Step Number */}
                <div className="relative z-10 flex-shrink-0">
                  <div className="w-16 h-16 bg-[#F7C600] rounded-full flex items-center justify-center text-black font-bold text-xl animate-pulse-glow">
                    {step.number}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 text-center md:text-left">
                  <h3 className="text-2xl font-bold text-black mb-3 font-['Montserrat']">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 text-lg">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Robot Designer Demo Section
function DesignerSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [selectedParts, setSelectedParts] = useState({
    body: 'standard',
    motor: 'medium',
    sensor: 'ultrasonic',
    wheel: 'tracked',
  });

  const parts = {
    body: [
      { id: 'standard', name: 'Standard Body', icon: <Cpu className="w-6 h-6" /> },
      { id: 'compact', name: 'Compact Body', icon: <Settings className="w-6 h-6" /> },
      { id: 'heavy', name: 'Heavy Duty', icon: <Battery className="w-6 h-6" /> },
    ],
    motor: [
      { id: 'small', name: 'Small Motor', icon: <Zap className="w-6 h-6" /> },
      { id: 'medium', name: 'Medium Motor', icon: <Zap className="w-6 h-6" /> },
      { id: 'large', name: 'Large Motor', icon: <Zap className="w-6 h-6" /> },
    ],
    sensor: [
      { id: 'ultrasonic', name: 'Ultrasonic', icon: <Eye className="w-6 h-6" /> },
      { id: 'infrared', name: 'Infrared', icon: <Wifi className="w-6 h-6" /> },
      { id: 'camera', name: 'Camera', icon: <Move className="w-6 h-6" /> },
    ],
    wheel: [
      { id: 'standard', name: 'Standard Wheels', icon: <Move className="w-6 h-6" /> },
      { id: 'tracked', name: 'Tracked', icon: <Layers className="w-6 h-6" /> },
      { id: 'omni', name: 'Omni Wheels', icon: <Settings className="w-6 h-6" /> },
    ],
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.designer-panel',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      id="designer" 
      ref={sectionRef}
      className="py-24 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            Try It Now
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 font-['Montserrat']">
            Visual Robot Designer
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Select parts and see your robot come to life. This is a simplified demo - 
            the full version has 100+ parts!
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Parts Panel */}
          <div className="designer-panel lg:col-span-1 space-y-4">
            <Tabs defaultValue="body" className="w-full">
              <TabsList className="grid grid-cols-4 bg-gray-900">
                <TabsTrigger value="body" className="data-[state=active]:bg-[#F7C600] data-[state=active]:text-black">
                  <Cpu className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="motor" className="data-[state=active]:bg-[#F7C600] data-[state=active]:text-black">
                  <Zap className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="sensor" className="data-[state=active]:bg-[#F7C600] data-[state=active]:text-black">
                  <Eye className="w-4 h-4" />
                </TabsTrigger>
                <TabsTrigger value="wheel" className="data-[state=active]:bg-[#F7C600] data-[state=active]:text-black">
                  <Move className="w-4 h-4" />
                </TabsTrigger>
              </TabsList>
              
              {Object.entries(parts).map(([category, categoryParts]) => (
                <TabsContent key={category} value={category} className="mt-4">
                  <div className="space-y-2">
                    {categoryParts.map((part) => (
                      <button
                        key={part.id}
                        onClick={() => setSelectedParts({ ...selectedParts, [category]: part.id })}
                        className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all ${
                          selectedParts[category as keyof typeof selectedParts] === part.id
                            ? 'bg-[#F7C600] border-[#F7C600] text-black'
                            : 'bg-gray-900 border-gray-800 text-white hover:border-[#F7C600]/50'
                        }`}
                      >
                        {part.icon}
                        <span className="font-medium">{part.name}</span>
                        {selectedParts[category as keyof typeof selectedParts] === part.id && (
                          <Check className="w-5 h-5 ml-auto" />
                        )}
                      </button>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {/* Preview Panel */}
          <div className="designer-panel lg:col-span-2">
            <div className="bg-gray-900 rounded-2xl p-8 h-full min-h-[400px] flex flex-col">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white font-['Montserrat']">Robot Preview</h3>
                <div className="flex gap-2">
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-1 animate-pulse" />
                    Live
                  </Badge>
                </div>
              </div>

              {/* Robot Preview Area */}
              <div className="flex-1 flex items-center justify-center relative">
                <div className="relative w-64 h-64">
                  {/* Robot Body */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-40 h-48 bg-[#F7C600] rounded-2xl relative shadow-2xl">
                      {/* Robot Face */}
                      <div className="absolute top-6 left-1/2 -translate-x-1/2 w-28 h-20 bg-black rounded-xl flex items-center justify-center gap-4">
                        <div className="w-6 h-6 bg-cyan-400 rounded-full animate-pulse" />
                        <div className="w-6 h-6 bg-cyan-400 rounded-full animate-pulse" />
                      </div>
                      {/* Antenna */}
                      <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-1 h-8 bg-gray-600">
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full animate-pulse" />
                      </div>
                      {/* Sensor Indicator */}
                      <div className="absolute top-28 left-1/2 -translate-x-1/2 flex gap-2">
                        {selectedParts.sensor === 'ultrasonic' && (
                          <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                            <Eye className="w-4 h-4 text-cyan-400" />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Wheels */}
                  <div className="absolute bottom-4 left-4 w-12 h-16 bg-gray-800 rounded-lg" />
                  <div className="absolute bottom-4 right-4 w-12 h-16 bg-gray-800 rounded-lg" />

                  {/* Sensor Rays */}
                  {selectedParts.sensor === 'ultrasonic' && (
                    <>
                      <div className="absolute top-1/2 left-0 w-20 h-0.5 bg-gradient-to-r from-cyan-400/50 to-transparent -rotate-12 origin-right" />
                      <div className="absolute top-1/2 right-0 w-20 h-0.5 bg-gradient-to-l from-cyan-400/50 to-transparent rotate-12 origin-left" />
                    </>
                  )}
                </div>
              </div>

              {/* Specs */}
              <div className="mt-6 grid grid-cols-3 gap-4">
                <div className="bg-gray-800 rounded-lg p-3 text-center">
                  <div className="text-[#F7C600] font-bold">Medium</div>
                  <div className="text-xs text-gray-400">Speed</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3 text-center">
                  <div className="text-[#F7C600] font-bold">2 hrs</div>
                  <div className="text-xs text-gray-400">Battery</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3 text-center">
                  <div className="text-[#F7C600] font-bold">50cm</div>
                  <div className="text-xs text-gray-400">Range</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Learning Section
function LearningSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.learning-card',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const levels = [
    {
      title: 'Beginner',
      icon: <Lightbulb className="w-8 h-8" />,
      color: 'bg-green-500',
      description: 'Start your robotics journey with basic concepts',
      topics: ['What is a robot?', 'Basic parts & sensors', 'Simple movements', 'Your first build'],
      lessons: 12,
      duration: '4 weeks',
    },
    {
      title: 'Intermediate',
      icon: <Code className="w-8 h-8" />,
      color: 'bg-[#F7C600]',
      description: 'Learn programming and advanced mechanics',
      topics: ['Block coding', 'Sensor programming', 'Obstacle avoidance', 'Line following'],
      lessons: 18,
      duration: '6 weeks',
    },
    {
      title: 'Advanced',
      icon: <Trophy className="w-8 h-8" />,
      color: 'bg-red-500',
      description: 'Master robotics and build complex projects',
      topics: ['AI & Machine Learning', 'Computer vision', 'Autonomous navigation', 'Competition robots'],
      lessons: 24,
      duration: '8 weeks',
    },
  ];

  return (
    <section 
      id="learn" 
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            Learning Paths
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4 font-['Montserrat']">
            Learn at Your Own Pace
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Structured learning paths take you from complete beginner to robotics master.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {levels.map((level, index) => (
            <Card 
              key={index}
              className="learning-card overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
            >
              <div className={`${level.color} p-6 text-white`}>
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                  {level.icon}
                </div>
                <h3 className="text-2xl font-bold font-['Montserrat']">{level.title}</h3>
                <p className="text-white/80 mt-2">{level.description}</p>
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <BookOpen className="w-4 h-4" />
                    {level.lessons} lessons
                  </span>
                  <span className="flex items-center gap-1">
                    <Move className="w-4 h-4" />
                    {level.duration}
                  </span>
                </div>
                
                <ul className="space-y-2">
                  {level.topics.map((topic, i) => (
                    <li key={i} className="flex items-center gap-2 text-gray-700">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {topic}
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full mt-6 ${
                    index === 1 
                      ? 'bg-[#F7C600] hover:bg-[#e0b500] text-black' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
                >
                  Start Learning
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: '100+', label: 'Video Lessons' },
            { value: '50+', label: 'Projects' },
            { value: '10K+', label: 'Students' },
            { value: '95%', label: 'Completion Rate' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl font-bold text-[#F7C600] font-['Montserrat']">{stat.value}</div>
              <div className="text-gray-600 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Testimonials Section
function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.testimonial-card',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const testimonials = [
    {
      quote: "My son built his first robot in 20 minutes! The visual designer is so intuitive that kids can immediately start creating.",
      author: 'Sarah M.',
      role: 'Parent',
      avatar: '/avatar-sarah.jpg',
      rating: 5,
    },
    {
      quote: "As a teacher, I've tried many educational platforms. BotForge is by far the best for teaching robotics concepts in an engaging way.",
      author: 'Mr. Johnson',
      role: 'Science Teacher',
      avatar: '/avatar-johnson.jpg',
      rating: 5,
    },
    {
      quote: "So much fun, I forget I'm learning! The simulator is like a video game where you actually learn real skills.",
      author: 'Alex, 12',
      role: 'Student',
      avatar: '/avatar-alex.jpg',
      rating: 5,
    },
  ];

  return (
    <section 
      ref={sectionRef}
      className="py-24 bg-[#F7F7F7]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            Testimonials
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4 font-['Montserrat']">
            Loved by Future Engineers
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            See what students, parents, and teachers are saying about BotForge.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="testimonial-card border-0 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <CardContent className="p-8">
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#F7C600] text-[#F7C600]" />
                  ))}
                </div>

                <p className="text-gray-700 text-lg mb-6 italic">
                  "{testimonial.quote}"
                </p>

                <div className="flex items-center gap-4">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.author}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-bold text-black">{testimonial.author}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

// Pricing Section
function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.pricing-card',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: '/month',
      description: 'Perfect for getting started',
      features: [
        'Basic robot designer',
        '5 project templates',
        'Beginner lessons',
        'Community support',
      ],
      cta: 'Get Started',
      highlighted: false,
    },
    {
      name: 'Pro',
      price: '$19',
      period: '/month',
      description: 'Best for serious learners',
      features: [
        'Advanced robot designer',
        '50+ project templates',
        'All learning paths',
        'Virtual simulator',
        'Code export',
        'Priority support',
      ],
      cta: 'Start Pro Trial',
      highlighted: true,
    },
    {
      name: 'Team',
      price: '$49',
      period: '/month',
      description: 'For classrooms & teams',
      features: [
        'Everything in Pro',
        'Up to 10 users',
        'Classroom management',
        'Progress tracking',
        'Custom curriculum',
        'Dedicated support',
      ],
      cta: 'Contact Sales',
      highlighted: false,
    },
  ];

  return (
    <section 
      id="pricing" 
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge className="bg-[#F7C600]/10 text-[#F7C600] border-[#F7C600]/30 mb-4">
            Pricing
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4 font-['Montserrat']">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Start free and upgrade when you're ready. No hidden fees, cancel anytime.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-center">
          {plans.map((plan, index) => (
            <Card 
              key={index}
              className={`pricing-card border-0 transition-all duration-300 ${
                plan.highlighted 
                  ? 'shadow-2xl scale-105 z-10' 
                  : 'shadow-lg hover:shadow-xl'
              }`}
            >
              {plan.highlighted && (
                <div className="bg-[#F7C600] text-black text-center py-2 text-sm font-bold">
                  MOST POPULAR
                </div>
              )}
              <CardContent className={`p-8 ${plan.highlighted ? 'pt-6' : ''}`}>
                <h3 className="text-xl font-bold text-black mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-4xl font-bold text-black font-['Montserrat']">{plan.price}</span>
                  <span className="text-gray-500">{plan.period}</span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-700">
                      <Check className={`w-5 h-5 flex-shrink-0 ${plan.highlighted ? 'text-[#F7C600]' : 'text-green-500'}`} />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full ${
                    plan.highlighted 
                      ? 'bg-[#F7C600] hover:bg-[#e0b500] text-black font-bold' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
                >
                  {plan.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

// CTA Section
function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.cta-content',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="py-24 bg-[#F7C600] relative overflow-hidden"
    >
      {/* Decorative Elements */}
      <div className="absolute top-10 left-10 w-20 h-20 border-4 border-black/10 rounded-full" />
      <div className="absolute bottom-10 right-10 w-32 h-32 border-4 border-black/10 rotate-45" />
      <div className="absolute top-1/2 left-1/4 w-4 h-4 bg-black/20 rounded-full" />
      <div className="absolute top-1/3 right-1/3 w-6 h-6 bg-black/10 rounded-full" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="cta-content">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-black mb-6 font-['Montserrat']">
            Ready to Start Building?
          </h2>
          <p className="text-xl text-black/70 mb-8 max-w-2xl mx-auto">
            Join 50,000+ future engineers already creating amazing robots on BotForge.
            Start your journey today - it's free!
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg"
              className="bg-black hover:bg-gray-900 text-white font-bold px-8 py-6 text-lg"
            >
              Get Started Free
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-black/30 text-black hover:bg-black/10 px-8 py-6 text-lg"
            >
              <Users className="mr-2 w-5 h-5" />
              View Classroom Plans
            </Button>
          </div>

          <div className="mt-8 flex items-center justify-center gap-6 text-black/60 text-sm">
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              No credit card required
            </span>
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              Free forever plan
            </span>
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              Cancel anytime
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  const links = {
    Product: ['Features', 'Designer', 'Simulator', 'Learning', 'Pricing'],
    Resources: ['Documentation', 'Tutorials', 'Blog', 'Community', 'Support'],
    Company: ['About Us', 'Careers', 'Press', 'Partners', 'Contact'],
    Legal: ['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'GDPR'],
  };

  return (
    <footer className="bg-black text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-5 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <a href="#hero" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-[#F7C600] rounded-lg flex items-center justify-center">
                <Cpu className="w-6 h-6 text-black" />
              </div>
              <span className="font-bold text-xl font-['Montserrat']">BotForge</span>
            </a>
            <p className="text-gray-400 mb-6 max-w-sm">
              The all-in-one platform for learning robotics. Design, simulate, and build 
              robots from your browser.
            </p>
            <div className="flex gap-4">
              {['Twitter', 'YouTube', 'Discord', 'GitHub'].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-[#F7C600] hover:text-black transition-colors"
                >
                  <span className="text-xs font-bold">{social[0]}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4 className="font-bold mb-4 font-['Montserrat']">{category}</h4>
              <ul className="space-y-2">
                {items.map((item) => (
                  <li key={item}>
                    <a href="#" className="text-gray-400 hover:text-[#F7C600] transition-colors text-sm">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © 2026 BotForge. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <span>Made with</span>
            <span className="text-[#F7C600]">♥</span>
            <span>for future engineers</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Main App
function App() {
  useEffect(() => {
    // Initialize smooth scroll
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <HeroSection />
        <FeaturesSection />
        <HowItWorksSection />
        <DesignerSection />
        <LearningSection />
        <TestimonialsSection />
        <PricingSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
